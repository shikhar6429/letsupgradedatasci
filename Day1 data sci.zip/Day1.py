# Answer 1
print("Answer 1")
print("RAINBOW")
print("-----------------------")
# Answer 2
print("Answer 2")
print("LETS UPGRADE")
print("-----------------------")
# Answer 3
print("Answer 3")
costPrice=input()
sellingPrice=input()
if costPrice>sellingPrice:
    print("Loss")
elif costPrice<sellingPrice:
    print("Profit")
else:
    print("Neither")
print("-----------------------")
# Answer 4
print("Answer 4")
euro=int(input())
rupees=euro*80
print(rupees)
print("-----------------------")
